# The Weight of the Waves — Interactive Flipbook

A GitHub Pages-ready digital flipbook for **The Weight of the Waves** by R. A. Miranda.

## Files
- `index.html` — flipbook website and animated blue wave loading screen.
- `assets/the-weight-of-the-waves.pdf` — the original 33-page book PDF.

## Publish on GitHub Pages
1. Create a new GitHub repository.
2. Upload **all files and folders inside this package** (keep the `assets` folder).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then click **Save**.
6. Wait for GitHub Pages to publish the site. Open the URL shown in the Pages section.

The site uses PDF.js and PageFlip from public CDNs, so visitors need an internet connection for the flipbook libraries and Google Fonts. The PDF itself is included in this repository and loads using a relative path.
